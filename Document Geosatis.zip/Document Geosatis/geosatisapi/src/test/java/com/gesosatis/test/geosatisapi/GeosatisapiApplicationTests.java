package com.gesosatis.test.geosatisapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GeosatisapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
