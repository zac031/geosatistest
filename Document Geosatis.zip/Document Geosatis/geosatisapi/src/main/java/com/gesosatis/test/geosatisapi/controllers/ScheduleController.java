package com.gesosatis.test.geosatisapi.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.gesosatis.test.geosatisapi.entities.Schedule;
import com.gesosatis.test.geosatisapi.service.ScheduleService;

@RestController
@RequestMapping("/api")
public class ScheduleController {

	private ScheduleService scheduleService;
	
	@Autowired
	public ScheduleController(ScheduleService scheduleService) {
		this.scheduleService = scheduleService;
	}
	
	@GetMapping("/schedules")
	public List<Schedule> getAllSchedules(){
		return scheduleService.findAll(); 
	}
	
	@GetMapping("/schedules/{scheduleId}")
	public Schedule getSchedule(@PathVariable int scheduleId) {
		Schedule schedule = scheduleService.findById(scheduleId);
		if (schedule == null) {
			throw new ResponseStatusException(
					HttpStatus.NOT_FOUND, "Could not get schedule, id not found - " + scheduleId
					);
		}
		
		return schedule;
	}
	
	@PostMapping("/schedules")
	public Schedule addSchedule(@RequestBody Schedule schedule) {
		// If id passed in Json, forces to save item and not update
		schedule.setId(0);
		scheduleService.save(schedule);
		return schedule;
	}
	
	@PutMapping("/schedules")
	public Schedule updateSchedule(@RequestBody Schedule schedule) {
		scheduleService.save(schedule);
		return schedule;
	}
	
	@DeleteMapping("/schedules/{scheduleId}")
	public String deleteSchedule(@PathVariable int scheduleId) {
		Schedule schedule = scheduleService.findById(scheduleId);
		if (schedule == null) {
			throw new ResponseStatusException(
					HttpStatus.NOT_FOUND, "Could not get schedule, id not found - " + scheduleId
					);
		}
		scheduleService.deleteById(scheduleId);
		return "Schedule deleted with id = " + scheduleId;
	}
	
} 