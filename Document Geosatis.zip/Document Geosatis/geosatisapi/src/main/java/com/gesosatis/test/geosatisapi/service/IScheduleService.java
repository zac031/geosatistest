package com.gesosatis.test.geosatisapi.service;

import java.util.List;

import com.gesosatis.test.geosatisapi.entities.Schedule;

public interface IScheduleService {
	
	public List<Schedule> findAll();
	
	public Schedule findById(int id);
	
	public void save(Schedule schedule);
	
	public void deleteById(int id);

}
