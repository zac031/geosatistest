package com.gesosatis.test.geosatisapi.dao;

import java.util.List;

import com.gesosatis.test.geosatisapi.entities.Schedule;

public interface IScheduleDao {

	public List<Schedule> findAll();
	
	public Schedule findById(int id);
	
	public void save(Schedule schedule);
	
	public void deleteById(int id);
	
}
