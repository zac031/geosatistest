package com.gesosatis.test.geosatisapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GeosatisapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(GeosatisapiApplication.class, args);
	}

}
