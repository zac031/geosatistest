package com.gesosatis.test.geosatisapi.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gesosatis.test.geosatisapi.dao.ScheduleDao;
import com.gesosatis.test.geosatisapi.entities.Schedule;

@Service
public class ScheduleService implements IScheduleService {

	private ScheduleDao scheduleDao;
	
	@Autowired
	public ScheduleService(ScheduleDao scheduleDao) {
		this.scheduleDao = scheduleDao;
	}
	
	@Override
	@Transactional
	public List<Schedule> findAll() {
		return scheduleDao.findAll();
	}

	@Override
	@Transactional
	public Schedule findById(int id) {
		return scheduleDao.findById(id);
	}

	@Override
	@Transactional
	public void save(Schedule schedule) {
		scheduleDao.save(schedule);
	}

	@Override
	@Transactional
	public void deleteById(int id) {
		scheduleDao.deleteById(id);
	}

}
