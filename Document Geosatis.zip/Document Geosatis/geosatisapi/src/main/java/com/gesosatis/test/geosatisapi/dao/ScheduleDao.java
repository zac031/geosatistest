package com.gesosatis.test.geosatisapi.dao;

import java.util.List;

import javax.persistence.EntityManager;

import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.gesosatis.test.geosatisapi.entities.Schedule;

@Repository
public class ScheduleDao implements IScheduleDao {

	private EntityManager entityManager;
	
	@Autowired
	public ScheduleDao(EntityManager entityManager) {
		this.entityManager = entityManager;
	}
	
	@Override
	public List<Schedule> findAll() {
		Session currentSession = entityManager.unwrap(Session.class);
		Query<Schedule> theQuery = currentSession.createQuery("from Schedule", Schedule.class);
		List<Schedule> schedules = theQuery.getResultList();
		return schedules;
	}

	@Override
	public Schedule findById(int id) {
		Session currentSession = entityManager.unwrap(Session.class);
		Schedule schedule = currentSession.get(Schedule.class, id);
		return schedule;
	}

	@Override
	@Transactional
	public void save(Schedule schedule) {
		Session currentSession = entityManager.unwrap(Session.class);
		currentSession.saveOrUpdate(schedule);
	}

	@Override
	public void deleteById(int id) {
		Session currentSession = entityManager.unwrap(Session.class);
		Query query = currentSession.createQuery("delete from Schedule where id=:id");
		query.setParameter("id", id);
		query.executeUpdate();
	}

}
