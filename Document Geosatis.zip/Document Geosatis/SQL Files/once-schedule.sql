CREATE DATABASE  IF NOT EXISTS `geosatis_test`;
USE `geosatis_test`;

--
-- Table structure for table `once-schedule`
--

DROP TABLE IF EXISTS `once-schedule`;

CREATE TABLE `once-schedule` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dateFrom` datetime DEFAULT NULL,
  `dateTo` datetime DEFAULT NULL,
  `schedule_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_schedule_id` FOREIGN KEY (`schedule_id`) REFERENCES `schedule` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;

